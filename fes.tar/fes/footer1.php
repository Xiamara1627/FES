<table width="100%" align="center">
<!--<tr><td>&nbsp;</td></tr>-->
<tr>
<td align="center" valign="top">&nbsp;</td>
<td align="right"><font face="Times New Roman, Times, serif" size="-1" >Faculty Evaluation System beta<br/>Developed By: CSE Dept., GECH<br/>cse.gechassan@gmail.com</font></td>
</tr>
</table>