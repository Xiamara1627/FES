
<table id="one-column-emphasis" align="left" style="vertical-align:top" border="0" cellpadding="1" cellspacing="0">
	<tr ><td><a href="login_success.php">Home</a></td></tr>
	<tr><td><a href="batch.php">Batch</a></td></tr>
	<tr><td><a href="branch.php">Branch</a></td></tr>
	<tr><td><a href="faculty.php">Faculty</a></td></tr>
	<tr><td><a href="feed_ques.php">Feedback Ques</a></td></tr>
	<tr><td><a href="admin_para.php">Set Parameter</a></td></tr>
	<tr><td><a href="feedback.php">Feedback</a></td></tr>
	<tr><td><a href="change_passwd.php">Change Password</a></td></tr>
	<tr><td><a href="logout.php">Log out</a></td></tr>
 </table>
